IS-2014
=======

copy is_standalone.xml to ..../wildfly/standalone/
run ./standalone.sh --server-config=is_standalone.xml